$(function() {
    // 二级菜单鼠标滑过动画
    $('.menu-item').on('mouseenter', function() {
        $(this).find('.arrow').animate({marginLeft: '10px'}, 200);
      }).on('mouseleave', function() {
        $(this).find('.arrow').animate({marginLeft: '0'}, 200);
      });

    // 鼠标进入箭头飞入，鼠标移出箭头归位

    // 注意 $(this).find() 方法的使用

    // 注意jQuery里 hover()方法的写法
  
    // 顶部轮播图部分
 
    // 初始状态默认显示第一张图，对应第一个小圆点激活
  

    // 鼠标点击小圆点切换
  

    // 直播右侧部分点击切换面板


    // 选项卡部分
    // 右侧部分选项卡封装函数
  

    // 左侧部分通用选项卡封装函数
  

    // 获取所有含有id的对象，均传入ID值,调用左、右选项卡函数，生成选项卡
  

    // 番剧动态右侧轮播图

    // 鼠标移入切换

})